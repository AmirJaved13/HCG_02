﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow_Wave : MonoBehaviour {

//	[SerializeField] Transform target;            		// The target position that that camera will be following.
//
////	[SerializeField] float smoothingSpeed = 0.13f;       	// The speed with which the camera will be following the target.
//
//	[SerializeField] Vector3 offset;   					// Camera offeset
//
//	private void Start()
//	{
////		this.offset = this.target.position - base.transform.position;
//	}
//
//	private void LateUpdate()
//	{
//		base.transform.position = this.target.position + this.offset;
//	}

	public GameObject objectToFollow;

	public float speed = 2.0f;

	void LateUpdate () {
		float interpolation = speed * Time.deltaTime;

		Vector3 position = this.transform.position;

		position.y = Mathf.Lerp(this.transform.position.y, objectToFollow.transform.position.y, interpolation);
		position.x = transform.position.x;
		position.z = transform.position.z;

		this.transform.position = position;
	}
}
