﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mario_Animation : MonoBehaviour {

	[SerializeField] PlayerController_JMG player;

	Animator anim;

	void Awake(){
		anim = GetComponent<Animator> ();
	}

	void Update(){

		if(player.isDead){
			anim.SetBool ("mario_idle", true);
			anim.SetBool ("mario_jump", false);
			anim.SetBool ("mario_run", false);
		}else if(player.isRunning){
			anim.SetBool ("mario_idle", false);
			anim.SetBool ("mario_jump", false);
			anim.SetBool ("mario_run", true);
		}else if(player.isJumping){
			anim.SetBool ("mario_idle", false);
			anim.SetBool ("mario_jump", true);
			anim.SetBool ("mario_run", false);
		}

	}

}
