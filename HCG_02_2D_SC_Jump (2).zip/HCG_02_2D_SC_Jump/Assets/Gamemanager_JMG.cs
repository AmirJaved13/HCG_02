﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Gamemanager_JMG : MonoBehaviour {

	public static Gamemanager_JMG instance;

	public PlayerController_JMG player;
	[SerializeField] PlatformManager_JMG platformManager;
	[SerializeField] float speedMultiplier = 0.8f;
	[SerializeField] Text scoreText;
	[SerializeField] Text highScoreText;
	[SerializeField] Text diffText;
	[SerializeField] Text speedText;
	public GameObject replayButton;
	public float speed;

	public Difficulty difficulty;
	Difficulty prevDifficulty;

	public int score; 
	float delta;
	float startingSpeed;

	void Awake(){
		startingSpeed = speed;
		difficulty = Difficulty.EASY;
		prevDifficulty = difficulty;
		instance = this;
		replayButton.SetActive (false);
	}

	// Update is called once per frame
	void Update () {
		delta += Time.deltaTime;
		if (delta > 1 && !player.isDead) {
			score = score + 1;
			delta = 0;
		}

		scoreText.text = score.ToString ();
		highScoreText.text = PlayerPrefs.GetInt ("Jump_HighScore").ToString ();
		diffText.text = difficulty.ToString();
		speedText.text = speed.ToString ();

		if (!player.isDead) {
			if (score == 10) {	
				difficulty = Difficulty.NORMAL;
			} else if (score == 20) {
				difficulty = Difficulty.MEDIUM;
			} else if (score == 30) {
				difficulty = Difficulty.HARD;
			} else if (score == 40) {
				difficulty = Difficulty.INSANE;
			}

			if (difficulty != prevDifficulty) {
				speed = getNewSpeed (speed);
				prevDifficulty = difficulty;
			}
		} else {
			//playe dead condition
			difficulty = Difficulty.EASY; 
			speed = 0;
		}

		if (Input.GetKey (KeyCode.R)) {
			replay ();
		}
	}

	float getNewSpeed(float currentSpeed){
		Debug.Log (" currentSpeed " + currentSpeed);
		currentSpeed = currentSpeed + speedMultiplier;
//		currentSpeed = currentSpeed;
		Debug.Log (" currentSpeed " + currentSpeed + " speedmultiplier " + speedMultiplier);
		return currentSpeed;
	}

	public void replay(){
		score = 0;
		speed = startingSpeed;
		difficulty = Difficulty.EASY;
		platformManager.reset ();
		player.reset ();
//		player.gameObject.SetActive (true);
		player.isDead = false;
		replayButton.SetActive (false);
	}
}

[SerializeField]
public enum Difficulty
{
	EASY,
	NORMAL,
	MEDIUM,
	HARD,
	INSANE
}
