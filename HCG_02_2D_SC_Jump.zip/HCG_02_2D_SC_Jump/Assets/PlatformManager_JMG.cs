﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformManager_JMG : MonoBehaviour {

	[SerializeField] Transform leftLimit;
	[SerializeField] Transform rightLimit;

	[SerializeField] GameObject[] platformPrefabs;

	public List<GameObject> prefabPool = new List<GameObject>();
	[SerializeField] List<GameObject> usedPrefabs = new List<GameObject>();

	void Awake(){
		for (int i = 0; i < platformPrefabs.Length; i++) {
			prefabPool.Add (platformPrefabs [i]);
		}	
	}

	void Start(){
		for (int i = 0; i < platformPrefabs.Length; i++) {
			platformPrefabs [i].SetActive (false);
		}
		setInitialPlatform ();
	}

	Vector3 newPosition;

	void setInitialPlatform(){
		newPosition = Vector3.zero;
		for (int i = 0; i < 4; i++) {
			platformPrefabs [i].transform.position = newPosition;
			newPosition.x = newPosition.x + 14.2f;
			platformPrefabs [i].SetActive (true);
			prefabPool.Remove (platformPrefabs [i]);
			usedPrefabs.Add (platformPrefabs [i]);
			platformPrefabs [i].GetComponent<Platform> ().Refresh ();
		}
	}

	void Update(){
		managePlatform ();
	}

	void managePlatform(){
		//		Debug.Log ("managePlatform " + Vector3.Distance (player.transform.position, usedPrefabs [usedPrefabs.Count-1].transform.position)); 
		if (Vector3.Distance (leftLimit.position, usedPrefabs [0].transform.position) < 0.3f) {
			//			Debug.Log ("managePlatform");

			GameObject nextP = getNextPlatform ();
			newPosition.x = usedPrefabs [usedPrefabs.Count - 1].transform.position.x + 14.2f;
			nextP.transform.position = newPosition;
			nextP.SetActive (true);
			usedPrefabs.Add (nextP);
			nextP.GetComponent<Platform> ().Refresh ();
			GameObject go = usedPrefabs [0];
			prefabPool.Add (go);
			usedPrefabs.Remove (go);
		}

	}

	GameObject getNextPlatform(){
		GameObject go = prefabPool [Random.Range (0, prefabPool.Count)];
		prefabPool.Remove (go);
		return go;
	}

}
