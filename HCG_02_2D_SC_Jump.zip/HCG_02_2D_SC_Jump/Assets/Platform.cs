﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platform : MonoBehaviour {

	[SerializeField] float speed = 1;
	[SerializeField] hurdlesContainer[] hc;
	[SerializeField] bool noHurdles; // testing only

	void Start(){
	}

	public void Refresh(){
//		Debug.Log ("on enable");
		if (!noHurdles) {
			int index;
			int hurdleIndexer;

			for (int i = 0; i < hc.Length; i++) {
				for (int j = 0; j < hc [i].hurdles.Length; j++) {
					hc [i].hurdles [j].SetActive (false);
				}
			}

			for (int i = 0; i < hc.Length; i++) {
				for (int j = 0; j < hc [i].hurdles.Length; j++) {

					index = Random.Range (0, 3);
					if (index == 0) {
						hurdleIndexer = Random.Range (0, hc [i].hurdles.Length);
						hc [i].hurdles [hurdleIndexer].SetActive (true);
						break;
					}
				}
			}
		}

	}

	void OnDisable(){
		Debug.Log ("on Disable");
		for (int i = 0; i < hc.Length; i++) {
			for (int j = 0; j < hc[i].hurdles.Length; j++) {
				hc [i].hurdles [j].SetActive (false);
			}
		}
	}

	// Update is called once per frame
	void LateUpdate () {
		speed = Gamemanager_JMG.instance.speed;
		transform.Translate (Vector3.left * Time.deltaTime * speed);
	}

	[System.Serializable]
	class hurdlesContainer{
		public GameObject[] hurdles;
	}
}
 